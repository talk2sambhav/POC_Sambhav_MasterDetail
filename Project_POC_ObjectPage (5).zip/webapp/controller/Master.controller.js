sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("com.poc.Project_POC_ObjectPage.controller.Master", {
		onInit: function () {

		}
	});
});