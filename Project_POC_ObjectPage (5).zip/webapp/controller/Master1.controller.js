sap.ui.define([
	"sap/ui/core/mvc/Controller",
		'sap/m/MessageToast'
], function (Controller,MessageToast) {
	"use strict";

	return Controller.extend("com.poc.Project_POC_ObjectPage.controller.Master1", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.poc.Project_POC_ObjectPage.view.Master1
		 */
		onInit: function () {
			debugger;
			var oModel = new sap.ui.model.json.JSONModel("MasterWorkflowSet");
			var aMasterData, aDetailData, aResponse;
			var that = this;
			aMasterData = jQuery.ajax({
				type: "GET",
				contentType: "application/json",
				url: "https://mohawk-carpet--llc-zeql-sandbox-sample-srv.cfapps.eu10.hana.ondemand.com/CPL.xsodata/CPLView?$format=json&&$filter=ACCOUNT__C%20eq%20%27R.250524.0000%27%20and%20WAREHOUSE_CODE__C%20eq%20%27TXB%27",
				dataType: "json",
				async: false,
				crossDomain: true,
				success: function (data, textStatus, jqXHR) {
					aResponse = data.d.results;

					oModel.setProperty("/master", aResponse)
					MessageToast.show("Master api called Successfully!");
				}
			});

			aDetailData = jQuery.ajax({
				type: "GET",
				contentType: "application/json",
				url: "https://mohawk-carpet--llc-zeql-sandbox-sample-srv.cfapps.eu10.hana.ondemand.com/CPL.xsodata/CPLDetailView?$format=json&&$filter=RESIDENTIAL_PRODUCT_UNIQUE_KEY__C eq 'R.CDL11.LP.47'",
				dataType: "json",
				async: false,
				crossDomain: true,
				success: function (data, textStatus, jqXHR) {
					aResponse = data.d.results;

					oModel.setProperty("/detail", aResponse)
					that.getView().setModel(oModel);
					MessageToast.show("Detail api called Successfully!");
				}
			});

		

		},

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf com.poc.Project_POC_ObjectPage.view.Master1
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf com.poc.Project_POC_ObjectPage.view.Master1
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf com.poc.Project_POC_ObjectPage.view.Master1
		 */
		//	onExit: function() {
		//
		//	}

	});

});