sap.ui.define([
	"com/poc/Project_POC_ObjectPage/test/unit/controller/Master.controller"
], function () {
	"use strict";
});